--------------------------------------------------------------------------------
-- Testbench for: accumulator_8bit
-- Applies the required test sequence from the Mid-Term Lab Exam
-- (8-bit Accumulator) and self-checks every step with assert statements.
--------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity accumulator_8bit_tb is
end accumulator_8bit_tb;

architecture behavior of accumulator_8bit_tb is

    component accumulator_8bit
        Port ( CLK   : in  STD_LOGIC;
               RESET : in  STD_LOGIC;
               A     : in  STD_LOGIC_VECTOR (7 downto 0);
               B     : in  STD_LOGIC_VECTOR (7 downto 0);
               Q     : out STD_LOGIC_VECTOR (7 downto 0));
    end component;

    signal CLK_tb   : STD_LOGIC := '0';
    signal RESET_tb : STD_LOGIC := '0';
    signal A_tb     : STD_LOGIC_VECTOR (7 downto 0) := (others => '0');
    signal B_tb     : STD_LOGIC_VECTOR (7 downto 0) := (others => '0');
    signal Q_tb     : STD_LOGIC_VECTOR (7 downto 0);

    constant CLK_period : time := 10 ns;

begin

    -- Instantiate the Unit Under Test (UUT)
    UUT: accumulator_8bit port map (
        CLK   => CLK_tb,
        RESET => RESET_tb,
        A     => A_tb,
        B     => B_tb,
        Q     => Q_tb
    );

    -- Free-running clock, 10 ns period
    CLK_process: process
    begin
        CLK_tb <= '0';
        wait for CLK_period/2;
        CLK_tb <= '1';
        wait for CLK_period/2;
    end process;

    -- Stimulus process: required test sequence from the exam sheet
    stim_proc: process
    begin
        wait for 100 ns;

        -- Step 1: RESET = 1 -> Q must clear to 00000000
        RESET_tb <= '1'; A_tb <= "00000000"; B_tb <= "00000000";
        wait for CLK_period*2;
        assert (Q_tb = "00000000")
            report "FAIL: Step 1 - RESET did not clear Q" severity error;

        -- Step 2: RESET = 0, A=3, B=5 -> Q = 8  (00001000)
        RESET_tb <= '0'; A_tb <= "00000011"; B_tb <= "00000101";
        wait for CLK_period*2;
        assert (Q_tb = "00001000")
            report "FAIL: Step 2 - Q did not capture 3+5=8" severity error;

        -- Step 3: A=2, B=1 -> Q = 3  (00000011)
        A_tb <= "00000010"; B_tb <= "00000001";
        wait for CLK_period*2;
        assert (Q_tb = "00000011")
            report "FAIL: Step 3 - Q did not capture 2+1=3" severity error;

        -- Step 4: A=255, B=1 -> 8-bit overflow, Q = 0  (00000000)
        A_tb <= "11111111"; B_tb <= "00000001";
        wait for CLK_period*2;
        assert (Q_tb = "00000000")
            report "FAIL: Step 4 - Q did not wrap to 0 on overflow (255+1)" severity error;

        -- Step 5: A=170, B=5 -> Q = 175  (10101111)
        A_tb <= "10101010"; B_tb <= "00000101";
        wait for CLK_period*2;
        assert (Q_tb = "10101111")
            report "FAIL: Step 5 - Q did not capture 170+5=175" severity error;

        report "PASS: accumulator_8bit testbench completed" severity note;
        wait;
    end process;

end behavior;
