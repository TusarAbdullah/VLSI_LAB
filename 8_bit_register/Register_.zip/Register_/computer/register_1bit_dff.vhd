library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity register_1bit_dff is
    Port ( CLK   : in  STD_LOGIC;
           RESET : in  STD_LOGIC;
           LOAD  : in  STD_LOGIC;
           D     : in  STD_LOGIC;
           Q     : out STD_LOGIC);
end register_1bit_dff;
architecture Structural of register_1bit_dff is

    component d_flip_flop
        Port ( D   : in  STD_LOGIC;
               CLK : in  STD_LOGIC;
               Q   : out STD_LOGIC;
               Q_n : out STD_LOGIC);
    end component;

    signal D_ff  : STD_LOGIC;
    signal Q_int : STD_LOGIC;
	 
begin

    D_ff <= '0'   when RESET = '1' else
            D     when LOAD = '1' else
            Q_int;

    UUT: d_flip_flop port map ( D => D_ff, CLK => CLK, Q => Q_int, Q_n => open );

    Q <= Q_int;

end Structural;