/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/shared/Register_/computer/register_8bit_dff_tb.vhd";



static void work_a_1384760273_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 5184U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(121, ng0);
    t2 = (t0 + 5816);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(122, ng0);
    t2 = (t0 + 4208U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 4992);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(123, ng0);
    t2 = (t0 + 5816);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(124, ng0);
    t2 = (t0 + 4208U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 4992);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_1384760273_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int64 t8;
    unsigned char t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    unsigned char t28;
    unsigned char t29;
    char *t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    unsigned char t34;
    unsigned char t35;

LAB0:    t1 = (t0 + 5432U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(132, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 5240);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(135, ng0);
    t2 = (t0 + 5880);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(135, ng0);
    t2 = (t0 + 5944);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 6008);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 6072);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 6136);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 6200);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 6264);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 6328);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 6392);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 6456);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(137, ng0);
    t2 = (t0 + 4208U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t8 = (t3 * 2);
    t2 = (t0 + 5240);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(138, ng0);
    t2 = (t0 + 2792U);
    t4 = *((char **)t2);
    t16 = *((unsigned char *)t4);
    t17 = (t16 == (unsigned char)2);
    if (t17 == 1)
        goto LAB32;

LAB33:    t15 = (unsigned char)0;

LAB34:    if (t15 == 1)
        goto LAB29;

LAB30:    t14 = (unsigned char)0;

LAB31:    if (t14 == 1)
        goto LAB26;

LAB27:    t13 = (unsigned char)0;

LAB28:    if (t13 == 1)
        goto LAB23;

LAB24:    t12 = (unsigned char)0;

LAB25:    if (t12 == 1)
        goto LAB20;

LAB21:    t11 = (unsigned char)0;

LAB22:    if (t11 == 1)
        goto LAB17;

LAB18:    t10 = (unsigned char)0;

LAB19:    if (t10 == 1)
        goto LAB14;

LAB15:    t9 = (unsigned char)0;

LAB16:    if (t9 == 0)
        goto LAB12;

LAB13:    xsi_set_current_line(141, ng0);
    t2 = (t0 + 5880);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 6008);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 6072);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 6136);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 6200);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 6264);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 6328);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 6392);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 6456);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(145, ng0);
    t2 = (t0 + 5944);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(146, ng0);
    t2 = (t0 + 4208U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t8 = (t3 * 2);
    t2 = (t0 + 5240);
    xsi_process_wait(t2, t8);

LAB37:    *((char **)t1) = &&LAB38;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB12:    t2 = (t0 + 9568);
    xsi_report(t2, 34U, (unsigned char)2);
    goto LAB13;

LAB14:    t2 = (t0 + 3912U);
    t33 = *((char **)t2);
    t34 = *((unsigned char *)t33);
    t35 = (t34 == (unsigned char)2);
    t9 = t35;
    goto LAB16;

LAB17:    t2 = (t0 + 3752U);
    t30 = *((char **)t2);
    t31 = *((unsigned char *)t30);
    t32 = (t31 == (unsigned char)2);
    t10 = t32;
    goto LAB19;

LAB20:    t2 = (t0 + 3592U);
    t27 = *((char **)t2);
    t28 = *((unsigned char *)t27);
    t29 = (t28 == (unsigned char)2);
    t11 = t29;
    goto LAB22;

LAB23:    t2 = (t0 + 3432U);
    t24 = *((char **)t2);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)2);
    t12 = t26;
    goto LAB25;

LAB26:    t2 = (t0 + 3272U);
    t7 = *((char **)t2);
    t22 = *((unsigned char *)t7);
    t23 = (t22 == (unsigned char)2);
    t13 = t23;
    goto LAB28;

LAB29:    t2 = (t0 + 3112U);
    t6 = *((char **)t2);
    t20 = *((unsigned char *)t6);
    t21 = (t20 == (unsigned char)2);
    t14 = t21;
    goto LAB31;

LAB32:    t2 = (t0 + 2952U);
    t5 = *((char **)t2);
    t18 = *((unsigned char *)t5);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB34;

LAB35:    xsi_set_current_line(147, ng0);
    t2 = (t0 + 2792U);
    t4 = *((char **)t2);
    t16 = *((unsigned char *)t4);
    t17 = (t16 == (unsigned char)2);
    if (t17 == 1)
        goto LAB59;

LAB60:    t15 = (unsigned char)0;

LAB61:    if (t15 == 1)
        goto LAB56;

LAB57:    t14 = (unsigned char)0;

LAB58:    if (t14 == 1)
        goto LAB53;

LAB54:    t13 = (unsigned char)0;

LAB55:    if (t13 == 1)
        goto LAB50;

LAB51:    t12 = (unsigned char)0;

LAB52:    if (t12 == 1)
        goto LAB47;

LAB48:    t11 = (unsigned char)0;

LAB49:    if (t11 == 1)
        goto LAB44;

LAB45:    t10 = (unsigned char)0;

LAB46:    if (t10 == 1)
        goto LAB41;

LAB42:    t9 = (unsigned char)0;

LAB43:    if (t9 == 0)
        goto LAB39;

LAB40:    xsi_set_current_line(151, ng0);
    t2 = (t0 + 6456);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(151, ng0);
    t2 = (t0 + 6392);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(151, ng0);
    t2 = (t0 + 6328);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(151, ng0);
    t2 = (t0 + 6264);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(151, ng0);
    t2 = (t0 + 6200);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(151, ng0);
    t2 = (t0 + 6136);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(151, ng0);
    t2 = (t0 + 6072);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(151, ng0);
    t2 = (t0 + 6008);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(152, ng0);
    t2 = (t0 + 5944);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(153, ng0);
    t2 = (t0 + 4208U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t8 = (t3 * 2);
    t2 = (t0 + 5240);
    xsi_process_wait(t2, t8);

LAB64:    *((char **)t1) = &&LAB65;
    goto LAB1;

LAB36:    goto LAB35;

LAB38:    goto LAB36;

LAB39:    t2 = (t0 + 9602);
    xsi_report(t2, 28U, (unsigned char)2);
    goto LAB40;

LAB41:    t2 = (t0 + 3912U);
    t33 = *((char **)t2);
    t34 = *((unsigned char *)t33);
    t35 = (t34 == (unsigned char)2);
    t9 = t35;
    goto LAB43;

LAB44:    t2 = (t0 + 3752U);
    t30 = *((char **)t2);
    t31 = *((unsigned char *)t30);
    t32 = (t31 == (unsigned char)2);
    t10 = t32;
    goto LAB46;

LAB47:    t2 = (t0 + 3592U);
    t27 = *((char **)t2);
    t28 = *((unsigned char *)t27);
    t29 = (t28 == (unsigned char)2);
    t11 = t29;
    goto LAB49;

LAB50:    t2 = (t0 + 3432U);
    t24 = *((char **)t2);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)2);
    t12 = t26;
    goto LAB52;

LAB53:    t2 = (t0 + 3272U);
    t7 = *((char **)t2);
    t22 = *((unsigned char *)t7);
    t23 = (t22 == (unsigned char)2);
    t13 = t23;
    goto LAB55;

LAB56:    t2 = (t0 + 3112U);
    t6 = *((char **)t2);
    t20 = *((unsigned char *)t6);
    t21 = (t20 == (unsigned char)2);
    t14 = t21;
    goto LAB58;

LAB59:    t2 = (t0 + 2952U);
    t5 = *((char **)t2);
    t18 = *((unsigned char *)t5);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB61;

LAB62:    xsi_set_current_line(154, ng0);
    t2 = (t0 + 3912U);
    t4 = *((char **)t2);
    t16 = *((unsigned char *)t4);
    t17 = (t16 == (unsigned char)3);
    if (t17 == 1)
        goto LAB86;

LAB87:    t15 = (unsigned char)0;

LAB88:    if (t15 == 1)
        goto LAB83;

LAB84:    t14 = (unsigned char)0;

LAB85:    if (t14 == 1)
        goto LAB80;

LAB81:    t13 = (unsigned char)0;

LAB82:    if (t13 == 1)
        goto LAB77;

LAB78:    t12 = (unsigned char)0;

LAB79:    if (t12 == 1)
        goto LAB74;

LAB75:    t11 = (unsigned char)0;

LAB76:    if (t11 == 1)
        goto LAB71;

LAB72:    t10 = (unsigned char)0;

LAB73:    if (t10 == 1)
        goto LAB68;

LAB69:    t9 = (unsigned char)0;

LAB70:    if (t9 == 0)
        goto LAB66;

LAB67:    xsi_set_current_line(159, ng0);
    t2 = (t0 + 6008);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 6072);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 6136);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 6200);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 6264);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 6328);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 6392);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 6456);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(160, ng0);
    t2 = (t0 + 5944);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(161, ng0);
    t2 = (t0 + 4208U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t8 = (t3 * 2);
    t2 = (t0 + 5240);
    xsi_process_wait(t2, t8);

LAB91:    *((char **)t1) = &&LAB92;
    goto LAB1;

LAB63:    goto LAB62;

LAB65:    goto LAB63;

LAB66:    t2 = (t0 + 9630);
    xsi_report(t2, 40U, (unsigned char)2);
    goto LAB67;

LAB68:    t2 = (t0 + 2792U);
    t33 = *((char **)t2);
    t34 = *((unsigned char *)t33);
    t35 = (t34 == (unsigned char)2);
    t9 = t35;
    goto LAB70;

LAB71:    t2 = (t0 + 2952U);
    t30 = *((char **)t2);
    t31 = *((unsigned char *)t30);
    t32 = (t31 == (unsigned char)3);
    t10 = t32;
    goto LAB73;

LAB74:    t2 = (t0 + 3112U);
    t27 = *((char **)t2);
    t28 = *((unsigned char *)t27);
    t29 = (t28 == (unsigned char)2);
    t11 = t29;
    goto LAB76;

LAB77:    t2 = (t0 + 3272U);
    t24 = *((char **)t2);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)3);
    t12 = t26;
    goto LAB79;

LAB80:    t2 = (t0 + 3432U);
    t7 = *((char **)t2);
    t22 = *((unsigned char *)t7);
    t23 = (t22 == (unsigned char)2);
    t13 = t23;
    goto LAB82;

LAB83:    t2 = (t0 + 3592U);
    t6 = *((char **)t2);
    t20 = *((unsigned char *)t6);
    t21 = (t20 == (unsigned char)3);
    t14 = t21;
    goto LAB85;

LAB86:    t2 = (t0 + 3752U);
    t5 = *((char **)t2);
    t18 = *((unsigned char *)t5);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB88;

LAB89:    xsi_set_current_line(162, ng0);
    t2 = (t0 + 3912U);
    t4 = *((char **)t2);
    t16 = *((unsigned char *)t4);
    t17 = (t16 == (unsigned char)3);
    if (t17 == 1)
        goto LAB113;

LAB114:    t15 = (unsigned char)0;

LAB115:    if (t15 == 1)
        goto LAB110;

LAB111:    t14 = (unsigned char)0;

LAB112:    if (t14 == 1)
        goto LAB107;

LAB108:    t13 = (unsigned char)0;

LAB109:    if (t13 == 1)
        goto LAB104;

LAB105:    t12 = (unsigned char)0;

LAB106:    if (t12 == 1)
        goto LAB101;

LAB102:    t11 = (unsigned char)0;

LAB103:    if (t11 == 1)
        goto LAB98;

LAB99:    t10 = (unsigned char)0;

LAB100:    if (t10 == 1)
        goto LAB95;

LAB96:    t9 = (unsigned char)0;

LAB97:    if (t9 == 0)
        goto LAB93;

LAB94:    xsi_set_current_line(167, ng0);
    t2 = (t0 + 5944);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 6008);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 6072);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 6136);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 6200);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 6264);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 6328);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 6392);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 6456);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(169, ng0);
    t2 = (t0 + 5880);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(170, ng0);
    t2 = (t0 + 4208U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t8 = (t3 * 2);
    t2 = (t0 + 5240);
    xsi_process_wait(t2, t8);

LAB118:    *((char **)t1) = &&LAB119;
    goto LAB1;

LAB90:    goto LAB89;

LAB92:    goto LAB90;

LAB93:    t2 = (t0 + 9670);
    xsi_report(t2, 41U, (unsigned char)2);
    goto LAB94;

LAB95:    t2 = (t0 + 2792U);
    t33 = *((char **)t2);
    t34 = *((unsigned char *)t33);
    t35 = (t34 == (unsigned char)2);
    t9 = t35;
    goto LAB97;

LAB98:    t2 = (t0 + 2952U);
    t30 = *((char **)t2);
    t31 = *((unsigned char *)t30);
    t32 = (t31 == (unsigned char)3);
    t10 = t32;
    goto LAB100;

LAB101:    t2 = (t0 + 3112U);
    t27 = *((char **)t2);
    t28 = *((unsigned char *)t27);
    t29 = (t28 == (unsigned char)2);
    t11 = t29;
    goto LAB103;

LAB104:    t2 = (t0 + 3272U);
    t24 = *((char **)t2);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)3);
    t12 = t26;
    goto LAB106;

LAB107:    t2 = (t0 + 3432U);
    t7 = *((char **)t2);
    t22 = *((unsigned char *)t7);
    t23 = (t22 == (unsigned char)2);
    t13 = t23;
    goto LAB109;

LAB110:    t2 = (t0 + 3592U);
    t6 = *((char **)t2);
    t20 = *((unsigned char *)t6);
    t21 = (t20 == (unsigned char)3);
    t14 = t21;
    goto LAB112;

LAB113:    t2 = (t0 + 3752U);
    t5 = *((char **)t2);
    t18 = *((unsigned char *)t5);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB115;

LAB116:    xsi_set_current_line(171, ng0);
    t2 = (t0 + 2792U);
    t4 = *((char **)t2);
    t16 = *((unsigned char *)t4);
    t17 = (t16 == (unsigned char)2);
    if (t17 == 1)
        goto LAB140;

LAB141:    t15 = (unsigned char)0;

LAB142:    if (t15 == 1)
        goto LAB137;

LAB138:    t14 = (unsigned char)0;

LAB139:    if (t14 == 1)
        goto LAB134;

LAB135:    t13 = (unsigned char)0;

LAB136:    if (t13 == 1)
        goto LAB131;

LAB132:    t12 = (unsigned char)0;

LAB133:    if (t12 == 1)
        goto LAB128;

LAB129:    t11 = (unsigned char)0;

LAB130:    if (t11 == 1)
        goto LAB125;

LAB126:    t10 = (unsigned char)0;

LAB127:    if (t10 == 1)
        goto LAB122;

LAB123:    t9 = (unsigned char)0;

LAB124:    if (t9 == 0)
        goto LAB120;

LAB121:    xsi_set_current_line(174, ng0);
    t2 = (t0 + 9744);
    xsi_report(t2, 43U, (unsigned char)0);
    xsi_set_current_line(179, ng0);

LAB145:    *((char **)t1) = &&LAB146;
    goto LAB1;

LAB117:    goto LAB116;

LAB119:    goto LAB117;

LAB120:    t2 = (t0 + 9711);
    xsi_report(t2, 33U, (unsigned char)2);
    goto LAB121;

LAB122:    t2 = (t0 + 3912U);
    t33 = *((char **)t2);
    t34 = *((unsigned char *)t33);
    t35 = (t34 == (unsigned char)2);
    t9 = t35;
    goto LAB124;

LAB125:    t2 = (t0 + 3752U);
    t30 = *((char **)t2);
    t31 = *((unsigned char *)t30);
    t32 = (t31 == (unsigned char)2);
    t10 = t32;
    goto LAB127;

LAB128:    t2 = (t0 + 3592U);
    t27 = *((char **)t2);
    t28 = *((unsigned char *)t27);
    t29 = (t28 == (unsigned char)2);
    t11 = t29;
    goto LAB130;

LAB131:    t2 = (t0 + 3432U);
    t24 = *((char **)t2);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)2);
    t12 = t26;
    goto LAB133;

LAB134:    t2 = (t0 + 3272U);
    t7 = *((char **)t2);
    t22 = *((unsigned char *)t7);
    t23 = (t22 == (unsigned char)2);
    t13 = t23;
    goto LAB136;

LAB137:    t2 = (t0 + 3112U);
    t6 = *((char **)t2);
    t20 = *((unsigned char *)t6);
    t21 = (t20 == (unsigned char)2);
    t14 = t21;
    goto LAB139;

LAB140:    t2 = (t0 + 2952U);
    t5 = *((char **)t2);
    t18 = *((unsigned char *)t5);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB142;

LAB143:    goto LAB2;

LAB144:    goto LAB143;

LAB146:    goto LAB144;

}


extern void work_a_1384760273_2372691052_init()
{
	static char *pe[] = {(void *)work_a_1384760273_2372691052_p_0,(void *)work_a_1384760273_2372691052_p_1};
	xsi_register_didat("work_a_1384760273_2372691052", "isim/register_8bit_dff_tb_isim_beh.exe.sim/work/a_1384760273_2372691052.didat");
	xsi_register_executes(pe);
}
