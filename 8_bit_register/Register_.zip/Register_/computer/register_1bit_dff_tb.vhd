
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;

 
ENTITY register_1bit_dff_tb IS
END register_1bit_dff_tb;
 
ARCHITECTURE behavior OF register_1bit_dff_tb IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT register_1bit_dff
    PORT(
         CLK : IN  std_logic;
         RESET : IN  std_logic;
         LOAD : IN  std_logic;
         D : IN  std_logic;
         Q : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal CLK : std_logic := '0';
   signal RESET : std_logic := '0';
   signal LOAD : std_logic := '0';
   signal D : std_logic := '0';

 	--Outputs
   signal Q : std_logic;

   -- Clock period definitions
   constant CLK_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: register_1bit_dff PORT MAP (
          CLK => CLK,
          RESET => RESET,
          LOAD => LOAD,
          D => D,
          Q => Q
        );

   -- Clock process definitions
   CLK_process :process
   begin
		CLK <= '0';
		wait for CLK_period/2;
		CLK <= '1';
		wait for CLK_period/2;
   end process;
 
 
 
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
      wait for 100 ns;	

      -- Reset behavior
      RESET <= '1'; LOAD <= '0'; D <= '1';
      wait for CLK_period*2;
      assert (Q = '0') report "FAIL: reset did not clear register" severity error;

      RESET <= '0';
		
		 -- Load-enable gating: LOAD=0, Q must not change even though D changes
      D <= '1'; LOAD <= '0';
      wait for CLK_period*2;
      assert (Q = '0') report "FAIL: Q changed while LOAD=0" severity error;

      -- Correct capture on clock edge
      D <= '1'; LOAD <= '1';
      wait for CLK_period*2;
      assert (Q = '1') report "FAIL: Q did not capture D=1" severity error;
		
		
		      -- Hold again with LOAD=0 after a successful load
      D <= '0'; LOAD <= '0';
      wait for CLK_period*2;
      assert (Q = '1') report "FAIL: Q changed while LOAD=0 (after load)" severity error;

      -- Correct capture, value 2
      D <= '0'; LOAD <= '1';
      wait for CLK_period*2;
      assert (Q = '0') report "FAIL: Q did not capture D=0" severity error;
		
		-- Reset again mid-stream, confirm it overrides LOAD
      D <= '1'; LOAD <= '1'; RESET <= '1';
      wait for CLK_period*2;
      assert (Q = '0') report "FAIL: reset did not override load" severity error;

      report "PASS: register_1bit_dff testbench completed" severity note;
      wait;
   end process;


END;
