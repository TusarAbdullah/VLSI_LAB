
-- VHDL Instantiation Created from source file register_1bit_dff.vhd -- 11:13:42 09/20/2026
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT register_1bit_dff
	PORT(
		CLK : IN std_logic;
		RESET : IN std_logic;
		LOAD : IN std_logic;
		D : IN std_logic;          
		Q : OUT std_logic
		);
	END COMPONENT;

	Inst_register_1bit_dff: register_1bit_dff PORT MAP(
		CLK => ,
		RESET => ,
		LOAD => ,
		D => ,
		Q => 
	);


