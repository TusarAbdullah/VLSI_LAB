--------------------------------------------------------------------------------
-- Company: 
-- Engineer:
--
-- Create Date:   11:54:47 09/20/2026
-- Design Name:   
-- Module Name:   /home/ise/shared/Register_/computer/register_8bit_dff_tb.vhd
-- Project Name:  computer
-- Target Device:  
-- Tool versions:  
-- Description:   
-- 
-- VHDL Test Bench Created by ISE for module: register_8bit_dff
-- 
-- Dependencies:
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends
-- that these types always be used for the top-level I/O of a design in order
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--------------------------------------------------------------------------------
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY register_8bit_dff_tb IS
END register_8bit_dff_tb;
 
ARCHITECTURE behavior OF register_8bit_dff_tb IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT register_8bit_dff
    PORT(
         CLK : IN  std_logic;
         RESET : IN  std_logic;
         LOAD : IN  std_logic;
         D0 : IN  std_logic;
         D1 : IN  std_logic;
         D2 : IN  std_logic;
         D3 : IN  std_logic;
         D4 : IN  std_logic;
         D5 : IN  std_logic;
         D6 : IN  std_logic;
         D7 : IN  std_logic;
         Q0 : OUT  std_logic;
         Q1 : OUT  std_logic;
         Q2 : OUT  std_logic;
         Q3 : OUT  std_logic;
         Q4 : OUT  std_logic;
         Q5 : OUT  std_logic;
         Q6 : OUT  std_logic;
         Q7 : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal CLK : std_logic := '0';
   signal RESET : std_logic := '0';
   signal LOAD : std_logic := '0';
   signal D0 : std_logic := '0';
   signal D1 : std_logic := '0';
   signal D2 : std_logic := '0';
   signal D3 : std_logic := '0';
   signal D4 : std_logic := '0';
   signal D5 : std_logic := '0';
   signal D6 : std_logic := '0';
   signal D7 : std_logic := '0';

 	--Outputs
   signal Q0 : std_logic;
   signal Q1 : std_logic;
   signal Q2 : std_logic;
   signal Q3 : std_logic;
   signal Q4 : std_logic;
   signal Q5 : std_logic;
   signal Q6 : std_logic;
   signal Q7 : std_logic;

   -- Clock period definitions
   constant CLK_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: register_8bit_dff PORT MAP (
          CLK => CLK,
          RESET => RESET,
          LOAD => LOAD,
          D0 => D0,
          D1 => D1,
          D2 => D2,
          D3 => D3,
          D4 => D4,
          D5 => D5,
          D6 => D6,
          D7 => D7,
          Q0 => Q0,
          Q1 => Q1,
          Q2 => Q2,
          Q3 => Q3,
          Q4 => Q4,
          Q5 => Q5,
          Q6 => Q6,
          Q7 => Q7
        );

   -- Clock process definitions
   CLK_process :process
   begin
		CLK <= '0';
		wait for CLK_period/2;
		CLK <= '1';
		wait for CLK_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
      wait for 100 ns;	

      -- Reset behavior: all bits must clear to 0
      RESET <= '1'; LOAD <= '0';
      D0<='1'; D1<='1'; D2<='1'; D3<='1'; D4<='1'; D5<='1'; D6<='1'; D7<='1';
      wait for CLK_period*2;
      assert (Q0='0' and Q1='0' and Q2='0' and Q3='0' and Q4='0' and Q5='0' and Q6='0' and Q7='0')
        report "FAIL: reset did not clear all bits" severity error;

      RESET <= '0';
		
		-- Load-enable gating: LOAD=0, Q must not change even though D changes
      D0<='1'; D1<='0'; D2<='1'; D3<='0'; D4<='1'; D5<='0'; D6<='1'; D7<='0';
      LOAD <= '0';
      wait for CLK_period*2;
      assert (Q0='0' and Q1='0' and Q2='0' and Q3='0' and Q4='0' and Q5='0' and Q6='0' and Q7='0')
        report "FAIL: Q changed while LOAD=0" severity error;
		  
		      -- Correct capture: pattern 10101010 (D7..D0)
      D7<='1'; D6<='0'; D5<='1'; D4<='0'; D3<='1'; D2<='0'; D1<='1'; D0<='0';
      LOAD <= '1';
      wait for CLK_period*2;
      assert (Q7='1' and Q6='0' and Q5='1' and Q4='0' and Q3='1' and Q2='0' and Q1='1' and Q0='0')
        report "FAIL: Q did not capture pattern 10101010" severity error;  
		  
		  
		      -- Hold again with LOAD=0
      D0<='0'; D1<='0'; D2<='0'; D3<='0'; D4<='0'; D5<='0'; D6<='0'; D7<='0';
      LOAD <= '0';
      wait for CLK_period*2;
      assert (Q7='1' and Q6='0' and Q5='1' and Q4='0' and Q3='1' and Q2='0' and Q1='1' and Q0='0')
        report "FAIL: Q changed while LOAD=0 (after load)" severity error;
		  
		 
		      -- Reset again mid-stream, confirm it overrides LOAD
      LOAD <= '1';
      D0<='1'; D1<='1'; D2<='1'; D3<='1'; D4<='1'; D5<='1'; D6<='1'; D7<='1';
      RESET <= '1';
      wait for CLK_period*2;
      assert (Q0='0' and Q1='0' and Q2='0' and Q3='0' and Q4='0' and Q5='0' and Q6='0' and Q7='0')
        report "FAIL: reset did not override load" severity error;
		  
		report "PASS: register_8bit_dff testbench completed" severity note;

		
		

      wait;
   end process;

END;
