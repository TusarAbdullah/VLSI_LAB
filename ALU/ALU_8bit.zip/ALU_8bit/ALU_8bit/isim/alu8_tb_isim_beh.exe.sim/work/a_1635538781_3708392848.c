/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/shared/ALU_8bit/ALU_8bit/alu8.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_3488546069778340532_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_3488768496604610246_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_374109322130769762_503743352(char *, unsigned char );


static void work_a_1635538781_3708392848_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(64, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t3, t5);
    t1 = (t0 + 2472U);
    t7 = *((char **)t1);
    t8 = *((unsigned char *)t7);
    t1 = (t0 + 1192U);
    t9 = *((char **)t1);
    t10 = *((unsigned char *)t9);
    t11 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t10);
    t12 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t8, t11);
    t13 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t6, t12);
    t1 = (t0 + 2632U);
    t14 = *((char **)t1);
    t15 = *((unsigned char *)t14);
    t16 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t13, t15);
    t1 = (t0 + 6048);
    t17 = (t1 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t16;
    xsi_driver_first_trans_fast(t1);

LAB2:    t21 = (t0 + 5952);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1635538781_3708392848_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    unsigned char t14;
    char *t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    char *t19;
    unsigned char t20;
    char *t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    char *t25;
    unsigned char t26;
    char *t27;
    unsigned char t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    unsigned char t32;
    char *t33;
    unsigned char t34;
    unsigned char t35;
    unsigned char t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;

LAB0:    xsi_set_current_line(68, ng0);

LAB3:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 3272U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t3, t5);
    t1 = (t0 + 1672U);
    t7 = *((char **)t1);
    t8 = *((unsigned char *)t7);
    t1 = (t0 + 3432U);
    t9 = *((char **)t1);
    t10 = *((unsigned char *)t9);
    t11 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t8, t10);
    t12 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t6, t11);
    t1 = (t0 + 1832U);
    t13 = *((char **)t1);
    t14 = *((unsigned char *)t13);
    t1 = (t0 + 3592U);
    t15 = *((char **)t1);
    t16 = *((unsigned char *)t15);
    t17 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t14, t16);
    t18 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t12, t17);
    t1 = (t0 + 1992U);
    t19 = *((char **)t1);
    t20 = *((unsigned char *)t19);
    t1 = (t0 + 3752U);
    t21 = *((char **)t1);
    t22 = *((unsigned char *)t21);
    t23 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t20, t22);
    t24 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t18, t23);
    t1 = (t0 + 2152U);
    t25 = *((char **)t1);
    t26 = *((unsigned char *)t25);
    t1 = (t0 + 3912U);
    t27 = *((char **)t1);
    t28 = *((unsigned char *)t27);
    t29 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t26, t28);
    t30 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t24, t29);
    t1 = (t0 + 2792U);
    t31 = *((char **)t1);
    t32 = *((unsigned char *)t31);
    t1 = (t0 + 4072U);
    t33 = *((char **)t1);
    t34 = *((unsigned char *)t33);
    t35 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t32, t34);
    t36 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t30, t35);
    t1 = (t0 + 6112);
    t37 = (t1 + 56U);
    t38 = *((char **)t37);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    *((unsigned char *)t40) = t36;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t41 = (t0 + 5968);
    *((int *)t41) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_1635538781_3708392848_init()
{
	static char *pe[] = {(void *)work_a_1635538781_3708392848_p_0,(void *)work_a_1635538781_3708392848_p_1};
	xsi_register_didat("work_a_1635538781_3708392848", "isim/alu8_tb_isim_beh.exe.sim/work/a_1635538781_3708392848.didat");
	xsi_register_executes(pe);
}
