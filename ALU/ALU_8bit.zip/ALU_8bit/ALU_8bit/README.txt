8-BIT ALU  (Xilinx ISE 14.7, VHDL)
==================================

Files
  alu8.vhd       Design: gates, full_adder, alu_slice, alu8 (top module)
  alu8_tb.vhd    Self-checking testbench (16 tests)
  ALU_8bit.xise  ISE project file (double-click to open)

How to run (ISim)
  1. Open ISE Project Navigator > File > Open Project > ALU_8bit.xise
  2. In the Design panel choose "Simulation" (top radio button).
  3. Select  alu8_tb  in the hierarchy.
  4. Double-click "Simulate Behavioral Model".
  5. In ISim:  Zoom to Full View. Change radix of signals to Binary/Decimal if needed.
  6. Check the ISim console (bottom): every test prints "PASS ..."
     and the last line must be "ALL TESTS PASSED".  Simulation ends at 160 ns.

How to synthesize / see RTL schematic
  1. Choose "Implementation" in the Design panel, select  alu8  (top).
  2. Synthesize - XST > View RTL Schematic.

Opcode table (op3 op2 op1 op0)
  0000 AND      0101 INC (A+1)
  0001 OR       0110 DEC (A-1)
  0010 NOT A    0111 ADD (A+B)
  0011 XOR      1000 SUB (A-B)
  0100 XNOR     others -> Y = 0
  cout : carry (ADD/INC) or borrow (SUB/DEC);  zero : Y = 00000000

Verified: all 16 tests pass (checked with GHDL, VHDL-93/2002/2008).
